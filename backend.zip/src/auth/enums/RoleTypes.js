const RoleTypes = {
    ADMIN: 100,
    USER: 10,
};

export default RoleTypes;
