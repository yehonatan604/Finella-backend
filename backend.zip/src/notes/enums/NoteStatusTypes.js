export const NoteStatusTypes = {
    PENDING: 'PENDING',
    READ: 'READ',
    ARCHIVED: 'ARCHIVED'
};