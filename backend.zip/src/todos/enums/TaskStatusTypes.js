const TaskStatusTypes = {
    PENDING: 'PENDING',
    COMPLETE: 'COMPLETE',
    FAILED: 'FAILED',
    CANCELLED: 'CANCELLED',
};

export default TaskStatusTypes;